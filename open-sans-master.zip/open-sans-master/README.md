# Open Sans Webfont Kit

Webfont kit for the awesome [Open Sans](http://www.google.com/fonts/specimen/Open+Sans) webfont.

Each typeface is split into a separate Sass partial, so it's easy to choose the typefaces you need and leave the rest out.

Compiled and minified CSS is also available.

Installable via [Bower](http://bower.io):

    bower install open-sans
